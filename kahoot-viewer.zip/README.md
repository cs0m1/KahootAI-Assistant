# Kahoot Question Viewer Extension

A Chrome extension that helps users view Kahoot questions and answers with AI-powered suggestions. The extension displays a minimalistic floating indicator that shows likely correct answers using color coding.

## Features

- Floating indicator that shows the likely correct answer through color
- AI-powered answer suggestions using Google's Gemini API
- Customizable display settings:
  - Auto-hide functionality
  - Adjustable hide delay
  - Multiple position options
  - Size options (small, medium, large)
  - Opacity control
- Works in both regular Kahoot and challenge modes
- Non-intrusive design that won't interfere with gameplay

## Installation

1. Clone or download this repository
2. Open Chrome and go to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked" and select the extension directory

## Setup

1. After installation, the extension will automatically open the settings page
2. Get a Gemini API key from [Google AI Studio](https://aistudio.google.com/apikey)
3. Enter your API key in the settings
4. Customize display settings to your preference

## Usage

1. Visit a Kahoot game or challenge
2. The extension will automatically detect questions and display a colored circle
3. The color indicates the likely correct answer:
   - In 4-answer mode: Red (1), Blue (2), Yellow (3), Green (4)
   - In 2-answer mode: Blue (1), Red (2)

## Files Structure

- `manifest.json` - Extension configuration and permissions
- `background.js` - Handles extension installation and options page
- `content.js` - Core functionality for question detection and display
- `options.html` - Settings page interface
- `options.js` - Settings page functionality

## Development

To modify or enhance the extension:

1. Make changes to the relevant files
2. Go to `chrome://extensions/`
3. Click the refresh icon on the extension card
4. Test your changes on a Kahoot game

## Privacy & Security

- The extension only activates on Kahoot.it domains
- API keys are stored locally in Chrome storage
- Question analysis is performed using Google's Gemini API
- No user data is collected or stored

## Contributing

Feel free to submit issues and enhancement requests!
